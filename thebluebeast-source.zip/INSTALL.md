Building TheBlueBeast
================

See doc/build-*.md for instructions on building the various
elements of the TheBlueBeast Core reference implementation of TheBlueBeast.
